KryMods Shop Bot

Установка:
1. Загрузить файлы на Bothost.
2. Установить зависимости из requirements.txt.
3. Открыть config.py.
4. Вставить новый токен BotFather.
5. Запустить main.py.

Администратор:
8017863607
