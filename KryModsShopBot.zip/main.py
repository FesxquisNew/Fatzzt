import asyncio
from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command
from aiogram.utils.keyboard import InlineKeyboardBuilder

from config import BOT_TOKEN, SHOP_NAME
from database import init_db, add_user

bot = Bot(BOT_TOKEN)
dp = Dispatcher()

@dp.message(Command("start"))
async def start(message: types.Message):
    await add_user(message.from_user.id, message.from_user.username)

    kb = InlineKeyboardBuilder()

    buttons = [
        ("🛒 Магазин", "shop"),
        ("💎 Профиль", "profile"),
        ("🪙 Пополнить", "pay"),
        ("📦 Покупки", "orders"),
        ("🛠 Поддержка", "support")
    ]

    for text, data in buttons:
        kb.button(text=text, callback_data=data)

    kb.adjust(2)

    await message.answer(
        f"⛏ Добро пожаловать в\n\n{SHOP_NAME}\n\n🟩 Магазин цифровых товаров",
        reply_markup=kb.as_markup()
    )

@dp.callback_query(lambda c: c.data == "shop")
async def shop(call: types.CallbackQuery):
    kb = InlineKeyboardBuilder()

    categories = [
        "🎮 Игровые аккаунты",
        "💎 Telegram NFT",
        "📱 Социальные сети",
        "📢 Telegram каналы",
        "⛏ Minecraft товары",
        "🔥 Другое"
    ]

    for category in categories:
        kb.button(text=category, callback_data="category")

    kb.adjust(1)

    await call.message.answer(
        "🛒 Выбери категорию:",
        reply_markup=kb.as_markup()
    )

async def main():
    await init_db()
    print("KryMods Shop Bot started")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
